<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'ysf0o_arisato' );

/** MySQL database username */
define( 'DB_USER', 'ysf0o_arisato' );

/** MySQL database password */
define( 'DB_PASSWORD', 'yuri_0869' );

/** MySQL hostname */
define( 'DB_HOST', 'mysql42.conoha.ne.jp' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'DCfjzTaEL0s%A{;cU%2OR/Y%Bmr&Ho{PS}Q<_>Fq4IGM9F{i&/ se8ph/|GRwuas' );
define( 'SECURE_AUTH_KEY',   'nU<}4hkI*kjArR.,>Q7Bw8`[s6!r=14b)1/d>hVRVz=RdWk?# f2.(%.@P.>DpFS' );
define( 'LOGGED_IN_KEY',     'cLh6].ot,]nep<?u-N@ Npf~ {UqYW?zs4Y(&H*anJ-lBD5o$9S.t<54})E%FS>?' );
define( 'NONCE_KEY',         'L0_@G_|Y}J`L?m+iC>ON#9}2n|F<~g T|~zGrHiS%3dR{YCPuSX$qz6Qe.bTs{4&' );
define( 'AUTH_SALT',         '!]>b}{C4:ugf_E73>uE~BJ5rea<,X|HN(@{24?3dmLLQuJ<60$)8B0xVCCZtkYvW' );
define( 'SECURE_AUTH_SALT',  'Sis<{pGU>5@t+r30kGav1jxh~x!M[l3+jom/0Dq;=PiI I#-${TYDPe<nOK?]>YW' );
define( 'LOGGED_IN_SALT',    '<OI`u?4F6Q{g%`,j(b_-{[c7o~SIE&.jW >?L7<0psk#n{4C;B%jyj!}@|$7@dyo' );
define( 'NONCE_SALT',        'B2l>kdL(l%S%KzV7Mer#;O1ORMl)1<G>t(OLy)ubfUc.sPgB)!L0;T5k+|4>1^68' );
define( 'WP_CACHE_KEY_SALT', ']~G0nHa%!77ki;vk>(UqXG#1D4wu>@@0M/uixX-2cH1Q3/,(!=5Kdm[Uq1j;^THW' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === "https") {
    $_SERVER['HTTPS'] = 'on';
    define('FORCE_SSL_LOGIN', true);
    define('FORCE_SSL_ADMIN', true);
}




define( 'CW_DASHBOARD_PLUGIN_SID', '-wO_8oKyEV7SuF1T2bTNkYDpvnySl6Kelh7rwxQoeKPa5dyYo4YycTxMfwti79GELM73mtM6i5NWkluzgLKyKX7yo-Xla4xEbL-8RXchkIU.' );
define( 'CW_DASHBOARD_PLUGIN_DID', 'V3ubFQeCwW2DnPpxDbLyPGwvbfwaiOp9PDD7m21xlxLHzJDyZM4n2ApPLRzCtV1O-CLYPoiuKODoWhUs5c84zrVDafwSEefnj2WcuJ0KOgI.' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
